		      1942: THE PACIFIC AIR WAR SCENARIO

Machine Requirements:
--------------------

   To run 1942: The Pacific Air War Scenario, you will need:

      1) 1942: The Pacific Air War
      2) A 386SX processor (386DX 33 MHz or higher recommended)
      3) 580k free conventional memory
      4) 1600k free EMS memory
      5) 9 Megabytes of hard drive space (this is required for 
	 installation only after installation only 6.5 Megabytes 
	 are required for game play files)
      6) A Joystick or mouse

NOTE  - 1942: The Pacific Air War and the Scenario have not 
	been tested under Microsoft Windows.

Design Changes
--------------

During the ongoing play test process, we made design adjustments
that could not be included in the manual or technical supplements.
The following is a list of these changes:


1. Autopilot
   When flying in training mode, the autopilot key will enable full
   computer control of your aircraft.  The autopilot will land,
   dive bomb, and make torpedo runs.  We encourage you to use this
   feature to learn how to perform difficult maneuvers (such as
   carrier landings!).

   When not in training mode, your autopilot will only takeoff,
   maintain formation on the way to and from the target, and fly
   your patrol route on CAP.  Landing, dogfighting, dive bombing,
   and torpedo bombing must be done by you.

2. Kill Credits
   Pilots are given credit for a kill based on the percentage of
   damage they inflicted on the plane.  If two pilots damaged the
   same enemy plane, the pilot who inflicted the most damage will
   get credit for the kill.  So you may not receive credit for a
   kill even if you are the last pilot to damage a plane.

3. Ditching
   Planes can be successfully ditched in the ocean.  You need to
   hit the water at a very slow speed (stall the plane below 50 
   ft.).  During a pilot career, ditching will be treated the same
   as if you bailed out (you will be rescued, captured, or killed).
   
4. Setting Cruising Altitudes
   When a strike flies to a target, there is always a lead flight
   that everyone else follows.  For mutual fire support reasons,
   the flights in a strike stay close to each other until they
   reach their target.  Because of this, you may only adjust the
   cruising altitude of the lead flight.  All other flights will
   automatically adjust their cruising altitudes to match.

5. Controlling Flights and Individual Planes
   While using the Flights menu in the map screen the Spacebar will 
   now toggle between control of the entire flight or individual 
   planes. 
   
6. Freeing Up Hard Drive Space
   If you wish to free some space on your hard drive, you can
   delete animations from the game.  1942 will detect that the
   animation files are missing, and continue to run normally
   The following files (and ONLY these files!) are O.K. to
   delete:

      OPEN.FLC    (1,563,324 bytes - 1942 title animation)
      MPSLOGO.FLC (  794,272 bytes - MicroProse animation)
      ANIM.CDF    (1,931,486 bytes - Carrier battle newsreels)

7. Virtual Cockpit Padlock Feature
   When you select the padlock feature from within the Virtual
   Cockpit, 1942 will lock on the enemy plane closest to the center
   of the screen.  The easiest way to padlock an enemy is to center
   the virtual cockpit view and use the gun sight to line up the
   enemy plane.

8. Carrier Battle 3-D Engagements
   If you abort out of a 3-D engagement before the mission is
   completed, the computer will finish the attack as if you had
   selected to observe.

   Keep in mind that, due to limitations in the number of planes
   that can be represented in 3-D, damage from large strikes will
   be a combination of the damage done in 3-D, and damage
   calculated statistically.  Your performance in 3-D, however,
   will have a limited effect upon the outcome of the statistical
   damage.

9. Realistic Flight Option
   The difference between realistic and non-realistic flight modes
   is quite significant.  We decided to combine all the realistic
   and potentially irritating problems that a pilot faces into this
   category.  The "purist" can select this mode to experience a 
   more accurate simulation of air combat, while the casual gamer
   can focus on the more "fun" elements.  Here is a list of 
   problems added in this mode:

   - Engine torque will effect flight.
   - Planes will shake and break apart if flown too fast.
   - Engines will overheat and burn up if kept at max power.
   - Torpedoes will fail if dropped at too high a speed or altitude.
   - Arrestor cables will be limited to the rear 1/3 of carrier.

10. Career Tailgunners
   After several heated debates, the design team/lead tester have
   agreed to allow tail gunners in the career.

11. Japanese Radios (or Lack Thereof)
   The Japanese usually preferred not to carry radios in their
   aircraft due to their excessive weight.  Therefore, as a
   Japanese pilot, you will not receive the radio messages the
   Americans did in flight.

12. Scuttling Ships in a Carrier Battle
   When severely damaged ships slow a Task Group down to a degree
   that is dangerous to the remaining ships, you should scuttle the
   ship.  This was not an uncommon practice used to prevent the
   enemy from capturing the ship.  You can scuttle ships in the
   Damaged Ships option in the Taskgroup menu. Select a displayed
   ship to scuttle.

13. Look-up View ('Z' key)
   In an effort to provide better visibility, 1942 has created a 
   45 degree 'lookup' view from the cockpit.  You can access this 
   view from any other view by pressing the <Z> key.  The key will 
   act as a toggle between the original view and the "lookup" view.
   If you are using a joystick with a hat switch (A 4 position 
   switch on the joystick. ie Thrustmaster, Flight Stick PRO ...) 
   to control your view angle, pushing the hat switch forward will
   toggle between the forward view and the 'lookup' view.
   
14. Carrier Battles
   The Carrier Battles have been modified to allow for surface 
   action between two opposing fleets.  The action will be resolved 
   on a statistical basis similar to that of Task Force:1942. 


MODEM PLAY:


Modem Initialization String
---------------------------

The files MODM28_8.TXT, MODM14_4.TXT, MODM9600.txt, and 
MODMINIT.TXT will be installed into your 1942 directory with
this update.  1942 will read the file MODMINIT.TXT to find
the initialization string for your modem.  The other three
files contain recommended initialization strings for 28.8K,
14.4K and 9600 baud modems.

If you are encountering any problems connecting make sure you have
selected the correct Comm Port and Baud Rate. If you are still 
having problems connecting to another modem, copy the appropriate
initialization string file to MODMINIT.TXT.  If you are still having
problems, change the initialization string in MODMINIT.TXT using 
any text editor (such as DOS EDIT). Consult the manual for your
modem for how to properly initialize your modem. The following 
command codes must be in the string "E0V0X0".

1942 does NOT use error correction or data compression.

Mission Builder
---------------

Using the Mission Builder, you can design your own modem 
missions within certain parameters.  A maximum of six aircraft
are allowable with a minimum of two.  When creating a Head to 
Head mission you must have a 'flyable' airplane on each side 
for it to be recognized, while in Cooperative, you need to 
have two flyable aircraft on the same side.

We suggest when designing your own missions to place the 
opposing flights extremely close to prevent a long uneventful
flight.  



ADDITIONAL INFO ON PADLOCK VIEW


While in the virtual cockpit, hitting the <J> key toggles the
padlock view on and off.  When the padlock view is initialized, it
will lock on the enemy plane that is closest to the center of the
screen.  The virtual cockpit will swivel to keep the enemy plane
centered.  While tracking the enemy plane, you can quickly return
to a forward looking viewpoint to regain your orientation.

If you are using the MOUSE to control the view angle:

While the padlock view is active, you must hold the left mouse
button down to view the enemy plane.  Otherwise, you will view
straight ahead.

If you are using the JOYSTICK to control the view angle:

While the padlock view is active, you must hold the second
joystick button down to view the enemy plane.  Otherwise, you
will view straight ahead.

If you are using the KEYBOARD or COOLIE HAT to control the view
angle:

While the padlock view is active, you must hold the <CTRL> key
down to view straight ahead.  Otherwise, you will view the enemy
plane.

We realize that the 'quick forward' view control is not
consistent between the various methods of view angle control, but
we chose the method that we felt worked best for each controller.

TECHNICAL ISSUES:


1. Thrustmaster WCS Mark II Support
   We have provided a configuration file for the WCS Mark II.  It's
   name is 1942PAW.ADV.  Consult your Thrustmaster documentation
   for instructions concerning how to upload this configuration.

2. Tandy Keyboard Problems
   If you are using a Tandy computer and are experiencing problems
   with the game not properly responding to game keystrokes, the
   'Alt' status of the keyboard has probably reversed.  That is,
   pressing 'A' results in an 'Alt-A' keystroke and vice-versa.
   To fix this problem, tap on the 'Alt' key until the status
   reverses back again.  We apologize for the inconvenience, but
   there seems to be something unique to the Tandy keyboard BIOS
   that causes this problem.  Our play testers using Tandy machines
   report that this problem occurs infrequently and does not
   significantly detract from the enjoyment of 1942.  We will try
   to work with Tandy to solve this problem in a future update.

3. BOOTDISK.EXE - EMM386 Problems
   In some Packard Bell, Tandy, IBM PS/1, Gateway 2000 computers or computers
   with network cards, there may be a problem with the standard Microprose
   bootdisk application and some memory configurations. If you experience
   a lock up and you are using a bootdisk made by the 1942 install program, 
   edit the CONFIG.SYS file on the bootdisk from:
   
   DEVICE=EMM386.EXE ram x=b000-c400 /d=48 frame=e000 6800
   
   TO:

    DOS 5.0 users:
   
      DEVICE=EMM386.EXE 2048 ram
   
    DOS 6.0 or later users:
   
      DEVICE=EMM386.EXE ram highscan
   
   If your hard drive is doublespaced, you are using the bootdisk,
   and you experience a problem, please add the following line to
   the end of the config.sys file on the bootdisk:
   
   DEVICEHIGH=C:\DOS\DBLSPACE.SYS /move

   Please note that if you are using QEMM v7.00 or later version and
   you are loading COMMAND.COM into a high region with DOSUP.SYS. 
   BOOTDISK.EXE will be not be able to load COMMAND.COM.  The solution is 
   to modify the SHELL statement in the CONFIG.SYS file on the bootdisk to:

   SHELL=A:\COMMAND.COM /p /e:384

4. BOOTDISK.EXE - Sound drivers
   Some sound cards require a sound driver to be loaded, either in CONFIG.SYS
   or AUTOEXEC.BAT. Due to the large number of sound cards available on the
   market today, BOOTDISK.EXE can not identify all of them.  If you are
   experiencing problems with sound, and are using a boot disk made by
   BOOTDISK.EXE then check AUTOEXEC.BAT and CONFIG.SYS on the boot disk 
   to see if the appropriate sound driver('s) were installed. If not then 
   refer to the manual for you sound card for what driver('s) that need to 
   be loaded.

5. Notes about Sound Card Detection

   Many sound cards do not have a means of being safely identified. We 
   have chosen to use only totally safe sound card detections (environment
   variables, drivers, etc). As a result, not all cards or options may be
   correctly detected, especially if the manufacturer's install was not 
   fully or correctly performed.

6. If you own a Sound Blaster, Pro Audio Spectrum, or Adlib Gold:

   In order to avoid these problems, the Install program performs
   sound card detection through a software only approach.  For Pro
   Audio Spectrum sound cards, the install will look for the 
   "MVSOUND.SYS" sound driver file.  For the Sound Blaster and 
   Adlib Gold cards, the install will check for the presence of an
   environmental variable, which contains a list of parameters 
   that define how the sound card is configured.

   If you are sure you own a Sound Blaster, Pro Audio Spectrum, or
   Adlib Gold, and the Install program does not seem to find your 
   card settings, you should double check if you ran the 
   install/configuration software that may have come with your 
   sound card.  These install/configuration programs often set up 
   the necessary information that the MicroProse Install program
   will look for.

7. If you own a Roland, General Midi, or other type of sound card:

   The MicroProse Install does not perform any checks for
   Roland, General Midi, or other types of sound cards.  You will 
   have to manually select your card in the card type menu and 
   select 'Configure Card' if your card is not set to factory 
   defaults.

8. New Digital Sound Support for SoundScape, Roland RAP-10:

   We have added digital sound support for the Roland RAP-10 and Ensoniq
   SoundScape cards in this version. If you are using the SoundScape for
   digitized sounds, the digital interrupt should be set to the SoundScape's
   BASE interrupt, not the Sound Blaster interrupt.

   Many MIDI sound cards use IRQ 9, but often call it IRQ 2. We have 
   tried to follow the manufacturer's conventions in most cases. If your
   option (2/9) is not shown, try the other one.

9. ISA Bus Speeds
   On computers that can have their ISA bus speeds greater than 8 MHZ, un-
   predictable results can occur.  For the complete safety of you machine 
   we recommend that the ISA bus speed not exceed 8 MHZ.


Modem Play
----------

To play modem missions both players need to select 'Modem Play' 
from the Main Menu.  Here, each player will need to select the 
appropriate settings for their individual modems: Comm Port and 
Baud Rate.

  Note!! the game will default to the slower baud rate 
  if they are different.

  DO NOT RUN A BAUD RATE FASTER THAN YOUR MODEM CAN HANDLE!
	(For Example, connecting at 19200 with a 14400 
	 modem.)
  DOING THIS WILL RESULT IN PLANES 'JUMPING' AROUND. RUN YOUR
  GAME AT THE FASTEST SPEED THE MODEM IS DESIGNED.   

Prior to play, a decision needs to be made as to whom the 
'Master' machine (Connect) and the 'Slave' machine (Wait on 
connection) will be.   
					   
The 'Modem Dial Menu' will only appear for the 'Master' machine.   
To dial a number, simply position mouse cursor over the 'Phone' 
window and click the LMB.  Type the desired number and press 
the <Enter> key when finished.  Press the button labeled <Dial> 
to complete the process. 
 
To facilitate frequently called numbers, 1942 allows for the 
storage of ten phone numbers.  To select a saved number, simply 
click on the desired number, which transfers the information
into the Name and Phone windows, and the press the <Dial> key.    

To edit a number, click on the slot where the number resides 
displaying the information in the corresponding windows: 'Name'
and 'Phone'.  Next, select(by clicking) the desired information 
to altered, edit the information and press the <ENTER> key.  
Creating new numbers is exactly the same procedure except 'Empty'
will appear in both windows instead of prior information.  

Once a link has been established, the 'Master' machine decides
on the mission parameters which include: Mission type, American/
Japanese, Cooperative versus Head to Head, and the actual mission. 

You can communicate to each other by clicking on the 'Message
Out' window, typing your desired message and pressing the <ENTER> 
key to send it.  The communication allows for the remote player 
to have some say in the decision process.  Ultimately, however, 
the decision rests in the hands of the 'Connector'.

Before the mission begins, both player will be given the 
'Difficulty Option' screen which either player may alter, but 
only the 'Master' machine can exit to begin the mission.  
Additionally, the 'Master' machine will be given the ability
to change the weather and time settings for the mission.

Unfortunately due to the lack of a 28.8k spec for high speed modems we 
have found that 28.8k modems will not always connect at that baud rate. 
To get the machines to connect try the next lower baud rate until a 
connect occurs. We apologize for any inconvenience this may cause.


Limitations
-----------

When playing modem missions certain functions are unavailable: 

1) Pilot's Map ('M') and all related map functions
2) Time Compression ('T' & 'R')

********************
**** THANK YOUS ****
********************

Thanks to the following people who helped our playtest efforts:
   Bob Abe             Scott Zlotak
   Charlie Andaloro    Mick Uhl
   Jim Hendry          Bill Burton
   Doug Whatley        Guy LaMarr
   Charles Brubaker    Todd Cioni
   Chrispy Bowling     Kathy Crowe
   Destin Strader      Jimmy Smith
   Damon Harris

   Last minute programming
   John Paquin
   
   Special Thanks 
   Michael Craighead

   Install Program
   Jack Miller
   Ned Way
