#!/bin/bash

# Set the environment variables
APPDIR="/usr/bin"
export PATH="$APPDIR/opt/python3.12/bin:$PATH"
export PYTHONPATH="$APPDIR/opt/python3.12/lib/python3.12/site-packages"

# Run the ratarmount script
$APPDIR/opt/python3.12/bin/python3.12 $APPDIR/opt/python3.12/bin/ratarmount "$@"

