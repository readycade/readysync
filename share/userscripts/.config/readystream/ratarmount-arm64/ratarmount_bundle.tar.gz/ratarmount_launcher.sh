#!/bin/sh

# Ensure the bundled libraries and binaries are available
export PATH=/opt/python3.12/bin:$PATH
export LD_LIBRARY_PATH=/opt/python3.12/lib:$LD_LIBRARY_PATH

# Execute ratarmount
/opt/python3.12/bin/python3.12 /opt/python3.12/bin/ratarmount "$@"

